class TestImport():

    def test_imports(self):
        from xgpy.Utility import Utility
        from xgpy.understat import UnderstatPlayer

        assert 1 == 1
