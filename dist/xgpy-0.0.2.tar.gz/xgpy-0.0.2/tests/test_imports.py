class TestImport():

    def test_imports(self):
        from xgpy.utility import Utility
        from xgpy.understat import UnderstatPlayer

        assert 1 == 1
