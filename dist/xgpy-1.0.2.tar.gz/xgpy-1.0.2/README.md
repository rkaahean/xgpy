A Python module to get data from www.understat.com

[![Build Status](https://travis-ci.com/rkaahean/xgpy.svg?branch=main)](https://travis-ci.com/rkaahean/xgpy)
[![HitCount](http://hits.dwyl.com/rkaahean/xgpy.svg)](http://hits.dwyl.com/rkaahean/xgpy)
[![Documentation Status](https://readthedocs.org/projects/xgpy/badge/?version=latest)](https://xgpy.readthedocs.io/en/latest/?badge=latest)
