#test output of get_player_match_data. See if all the headers are all right. See if the data received is not empty.
